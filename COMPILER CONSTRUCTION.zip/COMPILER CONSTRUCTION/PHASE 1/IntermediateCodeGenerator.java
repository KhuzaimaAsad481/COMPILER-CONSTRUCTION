package khuzaima;

import java.util.ArrayList;
import java.util.List;

public class IntermediateCodeGenerator {
    private List<String> intermediateCode;
    private int tempCount;

    public IntermediateCodeGenerator() {
        intermediateCode = new ArrayList<>();
        tempCount = 1;
    }

    private String generateTempVariable() {
        return "t" + tempCount++;
    }

    public void generateVariableDeclaration(String name, String type, String value) {
        String tempVar = generateTempVariable();
        intermediateCode.add(tempVar + " = " + value);
        intermediateCode.add(name + " = " + tempVar);
    }

    public void generateAssignment(String name, String expression) {
        String tempVar = generateTempVariable();
        intermediateCode.add(tempVar + " = " + expression);
        intermediateCode.add(name + " = " + tempVar);
    }

    public void generateLoopStart(String condition) {
        intermediateCode.add("LOOP_START if " + condition);
    }

    public void generateLoopEnd() {
        intermediateCode.add("LOOP_END");
    }

    public void generateOutput(String name) {
        intermediateCode.add("OUTPUT " + name);
    }

    public void printIntermediateCode() {
    	System.out.println("  ");
        System.out.println("------------Intermediate Code------------:");
        for (String code : intermediateCode) {
            System.out.println(code);
        }
    }
}
