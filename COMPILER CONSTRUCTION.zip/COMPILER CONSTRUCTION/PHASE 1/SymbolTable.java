package khuzaima;

import java.util.HashMap;
import java.util.Map;

public class SymbolTable {
    private Map<String, Variable> table;

    public SymbolTable() {
        table = new HashMap<>();
    }

    public void addVariable(String name, String type, String value) {
        Variable var = new Variable(name, type, value);
        table.put(name, var);
    }

    public void updateValue(String name, String value) {
        if (table.containsKey(name)) {
            Variable var = table.get(name);
            var.setValue(value);
        } else {
            System.out.println("Variable " + name + " not found.");
        }
    }

    public String getType(String name) {
        return table.containsKey(name) ? table.get(name).getType() : null;
    }

    public void printTable() {
    	System.out.println("  ");
    	System.out.println("------------Semantic Analysis------------");
        System.out.println("Semantic Analysis Successful");
        System.out.println("  ");
        System.out.println("------------Symbol Table------------");
        for (Variable var : table.values()) {
            System.out.println("Name: " + var.getName() + ", Type: " + var.getType() + ", Value: " + var.getValue());
        }
    }

    private class Variable {
        private String name, type, value;

        public Variable(String name, String type, String value) {
            this.name = name;
            this.type = type;
            this.value = value;
        }

        public String getName() { return name; }
        public String getType() { return type; }
        public String getValue() { return value; }
        public void setValue(String value) { this.value = value; }
    }
}

