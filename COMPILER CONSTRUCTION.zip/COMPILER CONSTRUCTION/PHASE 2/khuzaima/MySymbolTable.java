package khuzaima;
import java.util.HashMap;

public class MySymbolTable {
    private HashMap<String, Object> symbolTable; // Stores variable names and values
    private HashMap<String, String> types; // Stores variable types

    public MySymbolTable() {
        symbolTable = new HashMap<>();
        types = new HashMap<>();
    }

    // Declare a new variable in the symbol table
    public void declare(String name, Object value, String type) {
        if (symbolTable.containsKey(name)) {
            System.out.println("Error: Variable " + name + " is already declared.");
        } else {
            symbolTable.put(name, value);
            types.put(name, type);
            System.out.println("Declared: " + name + " = " + value + " (type: " + type + ")");
        }
    }

    // Assign a value to an existing variable
    public void assign(String name, Object value) {
        if (!symbolTable.containsKey(name)) {
            System.out.println("Error: Variable " + name + " is not declared.");
        } else {
            symbolTable.put(name, value);
            System.out.println("Assigned: " + name + " = " + value);
        }
    }

    // Get the value of a variable
    public Object get(String name) {
        if (!symbolTable.containsKey(name)) {
            System.out.println("Error: Variable " + name + " is not declared.");
            return null;
        }
        return symbolTable.get(name);
    }

    // Display the current symbol table
    public void show() {
        System.out.println("Symbol Table: ");
        for (String key : symbolTable.keySet()) {
            System.out.println(key + " = " + symbolTable.get(key) + " (type: " + types.get(key) + ")");
        }
    }

    // Main method for testing the symbol table
    public static void main(String[] args) {
        MySymbolTable symbolTable = new MySymbolTable();

        // Simulating variable declarations
        symbolTable.declare("num", 4, "int");
        symbolTable.declare("fact", 1, "int");

        // Simulating an assignment
        symbolTable.assign("fact", (Integer) symbolTable.get("fact") * (Integer) symbolTable.get("num"));
        symbolTable.assign("num", (Integer) symbolTable.get("num") - 1);

        // Display final symbol table
        symbolTable.show();
    }
}

